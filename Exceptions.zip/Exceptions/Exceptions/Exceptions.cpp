// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>


//Created a custom exception derrived from standard exception
class CustomException : public std::exception
{
public: 
    const char* what() const noexcept override {
        return "Custom exception";
    }
};

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception
    //Added standard overflow error exception
    throw std::overflow_error("Standard Exception has occurred");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;


    //Wrapped do_even_more_custom_application_logic() call with exception handler. 
    try {
        do_even_more_custom_application_logic();
    }
    catch (const std::exception& e) {
        std::cerr << "Exception: " << e.what() << std::endl;
    }

    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main

    //
    try {
        throw CustomException();
    }
    catch (const CustomException& e)
    {
        std::cerr << "Custom Exception caught: " << e.what() << std::endl;
    }


    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception

    //Check for and throw divide by zero error
    if (den== 0){
        throw std::runtime_error("Divide by zero error");
    }

    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;

    //Added try/catch for divide error. 
    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::exception& e) {
        std::cerr << "Exception: " << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.

    //Created try for main function
    try {
        do_division();
        do_custom_application_logic();
    }
    //First catch is for custom exception
    catch (const CustomException& e) {
        std::cerr << "Custom Exception in Main: " << e.what() << std::endl;
    }
    //Second catch for standard exception
    catch (const std::exception& e) {
        std::cerr << "Standard Exception in Main: " << e.what() << std::endl;
    }
    //Third catch for uncaught exceptions
    catch (...){
        std::cerr << "Other Exception in Main." << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu